<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../config/database.php';
    include_once '../class/registro.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new Employee($db);

    $stmt = $items->getEmployees();
    $itemCount = $stmt->rowCount();


    echo json_encode($itemCount);

    if($itemCount > 0){
        
        $credentialsArr = array();
        $credentialsArr["body"] = array();
        $credentialsArr["itemCount"] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $e = array(
                "user" => $user,
                "pass" => $pass,
                "document_type" => $document_type,
                "document_number" => $document_number,
                "created_date" => $created_date
            );

            array_push($credentialsArr["body"], $e);
        }
        echo json_encode($credentialsArr);
    }

    else{
        http_response_code(404);
        echo json_encode(
            array("message" => "No record found.")
        );
    }
?>